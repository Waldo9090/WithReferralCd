import SwiftUI
import FirebaseFirestore

struct ImageData {
    let image: UIImage
    let docID: String
    let ratings: [Int]
    let timestamp: Timestamp
}

struct HistoryView: View {
    @EnvironmentObject var globalContent: GlobalContent
    @StateObject private var viewModel = HistoryViewModel()
    @State private var isLoading = true

    var body: some View {
        NavigationView {
            ZStack {
                // Background Color
                Color(.systemBackground)
                    .edgesIgnoringSafeArea(.all)

                VStack(spacing: 20) {
                    // Title
                    Text("Your Scans")
                        .font(.system(size: 34, weight: .bold, design: .default))
                        .foregroundColor(.primary)
                        .padding(.top, 20)

                    if isLoading {
                        // Loading Indicator
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .primary))
                            .scaleEffect(1.5)
                            .padding(.top, 40)
                    } else {
                        // Always check Firebase for scans, don't rely on viewModel.hasScans
                        ScrollView {
                            LazyVStack(spacing: 20) {
                                if viewModel.imageData.isEmpty {
                                    // Show message when no scans are found
                                    VStack {
                                        Text("You haven't scanned anything yet!")
                                            .font(.headline)
                                            .foregroundColor(.secondary)
                                            .padding(.bottom, 20)
                                        
                                        Image(systemName: "photo.on.rectangle")
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 150, height: 150)
                                            .foregroundColor(.gray)
                                            .padding(.bottom, 20)

                                        Text("Once you scan something, it will appear here.")
                                            .font(.body)
                                            .foregroundColor(.secondary)
                                    }
                                } else {
                                    // Scanned Items List
                                    ForEach(viewModel.imageData, id: \.docID) { item in
                                        NavigationLink(destination: ImageDetailView(
                                            docID: item.docID,
                                            rating: item.ratings,
                                            globalImage: item.image
                                        ).navigationBarBackButtonHidden(true)) {
                                            VStack(alignment: .leading, spacing: 12) {
                                                // Timestamp
                                                Text("\(item.timestamp.dateValue(), formatter: dateFormatter)")
                                                    .font(.headline)
                                                    .foregroundColor(.primary)

                                                // Scanned Image
                                                Image(uiImage: item.image)
                                                    .resizable()
                                                    .aspectRatio(contentMode: .fill)
                                                    .frame(height: 200)
                                                    .clipped()
                                                    .cornerRadius(10)
                                                    .shadow(radius: 4)
                                            }
                                            .padding()
                                            .background(Color(.secondarySystemBackground))
                                            .cornerRadius(15)
                                            .shadow(color: Color.black.opacity(0.1), radius: 8, x: 0, y: 4)
                                            .padding(.horizontal)
                                        }
                                    }
                                }
                            }
                            .padding(.top, 10)
                        }
                    }
                }
                .padding(.bottom, 20)
                .onAppear {
                    isLoading = true
                    viewModel.fetchImages(email: globalContent.email) {
                        isLoading = false
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }
}


private let dateFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .medium
    formatter.timeStyle = .short
    return formatter
}()

class HistoryViewModel: ObservableObject {
    @Published var imageData: [(image: UIImage, docID: String, ratings: [Int], timestamp: Timestamp)] = []
    private let db = Firestore.firestore()

    func fetchImages(email: String?, completion: @escaping () -> Void) {
        // Check if email exists, if not fetch from UserDefaults
        let userEmail = email ?? UserDefaults.standard.string(forKey: "email")
        
        guard let userEmail = userEmail else {
            print("No email found")
            completion()
            return
        }
        
        // Print the email for debugging purposes
        print("Fetched email: \(userEmail)")

        let userDoc = db.collection("userRatings").document(userEmail)
        let timestampsCollection = userDoc.collection("timestamps")

        timestampsCollection.order(by: "timestamp", descending: true).getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching documents: \(error)")
                completion()
                return
            }

            guard let documents = snapshot?.documents else {
                print("No documents found.")
                self.imageData = [] // Clear imageData when no documents found
                completion()
                return
            }

            var seenDocIDs: Set<String> = Set() // Track seen document IDs
            var uniqueImages: [(image: UIImage, docID: String, ratings: [Int], timestamp: Timestamp)] = [] // To store unique images

            DispatchQueue.main.async {
                documents.forEach { doc in
                    let docID = doc.documentID
                    // Skip if we've already seen this document ID
                    if seenDocIDs.contains(docID) {
                        return
                    }
                    // Mark this document as seen
                    seenDocIDs.insert(docID)

                    guard let base64String = doc.data()["globalImage"] as? String,
                          let image = self.createImage(from: base64String),
                          let ratingArray = doc.data()["rating"] as? [Int],
                          let timestamp = doc.data()["timestamp"] as? Timestamp else {
                        return
                    }
                    uniqueImages.append((image: image, docID: docID, ratings: ratingArray, timestamp: timestamp))
                }
                self.imageData = uniqueImages // Assign unique images to imageData
                completion()
            }
        }
    }

    private func createImage(from base64String: String) -> UIImage? {
        guard let imageData = Data(base64Encoded: base64String, options: .ignoreUnknownCharacters) else {
            print("Failed to decode Base64 string.")
            return nil
        }
        return UIImage(data: imageData)
    }
}
