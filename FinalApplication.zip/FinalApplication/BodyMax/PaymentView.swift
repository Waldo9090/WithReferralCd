import SwiftUI
import UIKit
import SuperwallKit
import Firebase
import MessageUI
import Combine

// MARK: - AppState

/// ObservableObject to manage shared state across views.
class AppState: ObservableObject {
    /// Published property to signal when the share sheet should be dismissed.
    @Published var shouldDismissShareSheet: Bool = false
}

// MARK: - PaymentView

struct PaymentView: View {
    let globalImage: UIImage?
    @State private var capturedImage: UIImage? = nil
    @State private var isUmaxProActive: Bool = false
    @State private var showInviteSheet: Bool = false
    @State private var selectedTab = 1
    @StateObject private var appState = AppState() // Initialize AppState
    
    private var blurredRatings: [String] {
        ["Overall", "Potential", "Masculinity", "Skin quality", "Jawline", "Cheekbones"]
    }
    
    var body: some View {
        NavigationStack {
            GeometryReader { geometry in
                ZStack {
                    VStack(spacing: 20) { // Main vertical stack
                        // Profile image in circle
                        if let globalImage = globalImage {
                            Image(uiImage: globalImage)
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: geometry.size.width * 0.3, height: geometry.size.width * 0.3)
                                .clipShape(Circle())
                                .overlay(Circle().stroke(Color.black, lineWidth: 2))
                                .shadow(radius: 4)
                                .padding(.top, 10)
                        }
                        
                        // Blurred ratings section
                        VStack(spacing: 10) {
                            ForEach(blurredRatings, id: \.self) { rating in
                                HStack {
                                    Text(rating)
                                        .foregroundColor(.gray)
                                        .font(.system(size: 18, weight: .medium))
                                    
                                    Spacer()
                                    
                                    // Blurred progress bar
                                    RoundedRectangle(cornerRadius: 5)
                                        .fill(Color.gray.opacity(0.3))
                                        .frame(width: geometry.size.width * 0.5, height: 10)
                                }
                                .padding(.horizontal, 20)
                            }
                        }
                        
                        Spacer()
                        
                        // Umax Pro button
                        Button(action: {
                            Task {
                                Superwall.shared.register(event: "tab_trigger")
                                let result = await Superwall.shared.getPresentationResult(forEvent: "discount_trigger")
                                print("Superwall result: \(result)")
                                switch result {
                                case .userIsSubscribed:
                                    isUmaxProActive = true
                                    print("User is subscribed. Navigating to TabBarView.")
                                case .paywall:
                                    // Handle paywall presentation if needed
                                    print("Paywall presented.")
                                case .holdout:
                                    // Handle holdout group if needed
                                    print("User is in holdout group.")
                                case .eventNotFound, .noRuleMatch, .paywallNotAvailable:
                                    // Handle other cases as needed
                                    print("Event not found or no rule match.")
                                }
                            }
                        }) {
                            Text("💪 Get SwoleAI Pro")
                                .font(.system(size: 18, weight: .bold))
                                .frame(width: geometry.size.width * 0.8, height: 50)
                                .background(Color.purple)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .shadow(radius: 4)
                        }
                        .padding(.bottom, 10)
                        
                        // Invite Friends button
                        Button(action: {
                            showInviteSheet = true
                        }) {
                            Text("Invite 3 Friends")
                                .font(.system(size: 18, weight: .bold))
                                .frame(width: geometry.size.width * 0.8, height: 50)
                                .background(Color.black)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                                .shadow(radius: 4)
                        }
                        .padding(.bottom, 20)
                        .sheet(isPresented: $showInviteSheet) {
                            InviteFriendsSheet(isUmaxProActive: $isUmaxProActive)
                                .environmentObject(appState) // Pass AppState to InviteFriendsSheet
                        }
                        
                        Spacer() // Push content to the top
                    }
                    .frame(width: geometry.size.width, alignment: .top)
                    .background(Color.black.opacity(0.9))
                    .onAppear {
                        captureScreenshot()
                    }
                    .onChange(of: isUmaxProActive) { newValue in
                        if newValue {
                            print("isUmaxProActive changed to true")
                            // Additional logic if needed
                        }
                    }
                    
                    // Hidden NavigationLink
                    NavigationLink(
                        destination: TabBarView(selectedTab: $selectedTab)
                            .navigationBarHidden(true),
                        isActive: $isUmaxProActive
                    ) {
                        EmptyView()
                    }
                }
            }
            .navigationTitle("Payment View")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        // Go back action
                        // Implement your back navigation logic here
                        print("Back button tapped")
                        // Example using presentationMode:
                        // presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.gray)
                    }
                }
            }
        }
    }
    
    // Screenshot capture method (if needed)
    func captureScreenshot() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            withAnimation(nil) {
                guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                      let window = windowScene.windows.first else { return }
                let renderer = UIGraphicsImageRenderer(size: window.bounds.size)
                let image = renderer.image { ctx in
                    window.drawHierarchy(in: window.bounds, afterScreenUpdates: true)
                }
                capturedImage = image
                print("Screenshot captured.")
            }
        }
    }
}

// MARK: - InviteFriendsSheet

struct InviteFriendsSheet: View {
    @Binding var isUmaxProActive: Bool // Binding to modify isUmaxProActive in PaymentView
    @EnvironmentObject var appState: AppState // Observe AppState
    @Environment(\.presentationMode) var presentationMode // Access presentation mode to dismiss
    @State private var isShowingShareSheet: Bool = false // State to control share sheet
    @State private var referralCode: String = "" // State for the referral code
    @State private var redeemMessage: String = "" // State to display success or error messages
    private let db = Firestore.firestore() // Firestore instance
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Invite 3 Friends")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding()
            
            Text("Share the app with 3 friends and unlock more features!")
                .multilineTextAlignment(.center)
                .padding()
            
            // Display the referral code with a clipboard button
            HStack {
                Text("Your Referral Code: \(referralCode)")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Button(action: {
                    UIPasteboard.general.string = referralCode // Copy referral code to clipboard
                }) {
                    Image(systemName: "doc.on.doc")
                        .font(.title2)
                }
            }
            .padding()
            
            Button(action: {
                isShowingShareSheet = true // Show the share sheet
            }) {
                Text("Share Invite")
                    .font(.title2)
                    .fontWeight(.bold)
                    .frame(width: 250, height: 50)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .shadow(radius: 4)
            }
            .sheet(isPresented: $isShowingShareSheet) {
                // Present the share sheet using ActivityView
                ActivityView(activityItems: ["Join me on SwoleAI! Use my referral code: \(referralCode)"])
            }
            
            // Redeem referral code section
            Button(action: {
                redeemOwnReferralCode()
            }) {
                Text("Redeem")
                    .font(.headline)
                    .padding(.horizontal)
                    .padding(.vertical, 10)
                    .frame(width: 200)
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .shadow(radius: 4)
            }
            .padding(.top, 20)
            
            if !redeemMessage.isEmpty {
                Text(redeemMessage)
                    .foregroundColor(redeemMessage.contains("Success") ? .green : .red)
                    .padding()
            }
            
            Spacer()
        }
        .padding()
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 20)
        .onAppear {
            loadReferralCode() // Load referral code when the sheet appears
            checkOwnReferralCodeUsageCount() // Check the usage count of user's own referral code
        }
        .onReceive(appState.$shouldDismissShareSheet) { shouldDismiss in
            if shouldDismiss {
                isShowingShareSheet = false // Dismiss the share sheet
                // Reset the flag to avoid repeated dismissals
                DispatchQueue.main.async {
                    appState.shouldDismissShareSheet = false
                }
            }
        }
    }
    
    // Function to load referral code from UserDefaults or generate a new one
    func loadReferralCode() {
        if let savedReferralCode = UserDefaults.standard.string(forKey: "referralCode") {
            referralCode = savedReferralCode // Use the saved referral code
        } else {
            generateReferralCode() // Generate and save a new referral code
        }
    }
    
    // Function to generate a random 6-digit referral code and save to UserDefaults
    func generateReferralCode() {
        referralCode = String(format: "%06d", Int.random(in: 100000...999999))
        UserDefaults.standard.set(referralCode, forKey: "referralCode") // Save to UserDefaults
        saveReferralCodeToFirestore() // Save the code to Firestore
    }
    
    // Function to save the referral code to Firestore
    func saveReferralCodeToFirestore() {
        let referralData: [String: Any] = [
            "UsageCount": 0
        ]
        
        db.collection("ReferralCodes").document(referralCode).setData(referralData) { error in
            if let error = error {
                print("Error saving referral code: \(error.localizedDescription)")
            } else {
                print("Referral code saved successfully.")
            }
        }
    }
    
    // Function to check the user's own referral code's UsageCount
    func checkOwnReferralCodeUsageCount() {
        guard !referralCode.isEmpty else {
            print("Referral code is empty.")
            return
        }
        
        db.collection("ReferralCodes").document(referralCode).getDocument { (document, error) in
            if let error = error {
                print("Error fetching referral code: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    redeemMessage = "Error fetching referral code."
                }
                return
            }
            
            if let document = document, document.exists {
                if let usageCount = document.data()?["UsageCount"] as? Int {
                    if usageCount >= 3 {
                        DispatchQueue.main.async {
                            isUmaxProActive = true
                            redeemMessage = "Your referral code has been used \(usageCount) times. Umax Pro is now active!"
                            print("Your referral code has been used \(usageCount) times. Umax Pro is now active!")
                            
                            // Dismiss the sheet
                            presentationMode.wrappedValue.dismiss()
                            
                            // Reset UsageCount to 0 after successful redemption
                            db.collection("ReferralCodes").document(referralCode).updateData(["UsageCount": 0]) { error in
                                if let error = error {
                                    print("Error resetting UsageCount: \(error.localizedDescription)")
                                    // Optionally, update redeemMessage to inform the user
                                    DispatchQueue.main.async {
                                        redeemMessage = "Redeemed successfully, but failed to reset UsageCount."
                                    }
                                } else {
                                    print("UsageCount reset to 0.")
                                    // Optionally, update redeemMessage to confirm reset
                                    DispatchQueue.main.async {
                                        redeemMessage += " Usage count has been reset."
                                    }
                                }
                            }
                        }
                    } else {
                        DispatchQueue.main.async {
                            redeemMessage = "Your referral code has been used \(usageCount) times."
                            print("Your referral code has been used \(usageCount) times.")
                        }
                    }
                } else {
                    DispatchQueue.main.async {
                        print("Error retrieving usage count.")
                        redeemMessage = "Error retrieving usage count."
                    }
                }
            } else {
                // Document does not exist; create it with UsageCount set to 0
                print("Referral code does not exist in Firestore. Creating new document with UsageCount = 0.")
                let referralData: [String: Any] = [
                    "UsageCount": 0
                ]
                
                db.collection("ReferralCodes").document(referralCode).setData(referralData) { error in
                    if let error = error {
                        print("Error creating referral code: \(error.localizedDescription)")
                        DispatchQueue.main.async {
                            redeemMessage = "Error creating referral code."
                        }
                    } else {
                        print("Referral code created with UsageCount set to 0.")
                        DispatchQueue.main.async {
                            redeemMessage = "Referral code created. Usage count is 0."
                        }
                    }
                }
            }
        }
    }
    
    // Function to redeem own referral code by checking UsageCount
    func redeemOwnReferralCode() {
        // Directly check the UsageCount from Firestore
        checkOwnReferralCodeUsageCount()
    }
}

struct InviteFriendsSheet_Previews: PreviewProvider {
    @State static var isUmaxProActive: Bool = false
    
    static var previews: some View {
        InviteFriendsSheet(isUmaxProActive: $isUmaxProActive)
            .environmentObject(AppState())
            .previewDevice("iPhone 14")
    }
}

// MARK: - ActivityView

/// Wrapper for UIActivityViewController to use in SwiftUI
struct ActivityView: UIViewControllerRepresentable {
    let activityItems: [Any]
    let applicationActivities: [UIActivity]? = nil
    
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: applicationActivities)
    }
    
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {
        // No update needed
    }
}

struct ActivityView_Previews: PreviewProvider {
    static var previews: some View {
        ActivityView(activityItems: ["Sample text to share"])
            .previewDevice("iPhone 14")
    }
}


struct TabBarView_Previews: PreviewProvider {
    @State static var selectedTab: Int = 1
    
    static var previews: some View {
        TabBarView(selectedTab: $selectedTab)
            .previewDevice("iPhone 14")
    }
}
