import SwiftUI
import UIKit

struct ImageDetailView: View {
    let docID: String
    let rating: [Int]
    let globalImage: UIImage?
    @State private var capturedImage: UIImage? = nil
    @State private var analysisResult: String = ""
    @Environment(\.presentationMode) var presentationMode

    func calculateOverall(_ rating: [Int]) -> Int {
        guard !rating.isEmpty else { return 0 }
        return rating.reduce(0, +) / rating.count
    }

    private var ratingLabels: [String] {
        ["Chest", "Abdominal", "Shoulders", "Arms", "Veins", "Lean"]
    }

    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                ScrollView {
                    VStack(spacing: 20) { // Reduced spacing for better fit
                        // User's profile image
                        if let globalImage = globalImage {
                            Image(uiImage: globalImage)
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: geometry.size.width * 0.3, height: geometry.size.width * 0.3)
                                .clipShape(Circle())
                                .overlay(Circle().stroke(Color.black, lineWidth: 2))
                                .shadow(radius: 4)
                                .padding(.top, 10)
                        }

                        // Overall and Potential ratings
                        HStack(spacing: 20) { // Reduced spacing
                            OverallRatingView(overallRating: calculateOverall(Array(rating.dropLast()))) // Exclude last "Potential"
                                .font(.system(size: 50, weight: .bold)) // Slightly smaller font

                            PotentialRatingView(potentialRating: rating.last ?? 0) // Display Potential rating with black background
                        }
                        .frame(maxWidth: geometry.size.width * 0.9, alignment: .center) // Ensure HStack doesn't exceed screen width
                        .padding(.vertical, 5)

                        // Display individual ratings
                        RatingsListView(ratings: Array(rating.dropLast()), labels: ratingLabels)
                            .padding(.horizontal, 15) // Reduced horizontal padding

                        // Share button for screenshot
                        if let capturedImage = capturedImage {
                            ShareButton(capturedImage: $capturedImage)
                                .padding(.top, 10)
                                .padding(.bottom, 20) // Adjusted bottom padding
                        }

                        Spacer() // Pushes content to the top
                    }
                    .frame(width: geometry.size.width, alignment: .top)
                    .background(Color.white)
                    .onAppear {
                        captureScreenshot()
                    }
                }
            }
            .navigationBarTitle("Image Details", displayMode: .inline) // Use SwiftUI's navigation title
            .navigationBarItems(leading: Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                Image(systemName: "chevron.left")
                    .foregroundColor(.gray)
            })
            .navigationViewStyle(StackNavigationViewStyle()) // Ensure consistent NavigationView style
        }
    }

    func captureScreenshot() {
        // Add a short delay before capturing the screenshot without animation
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { // Reduced delay
            // Disable animations during screenshot capture
            withAnimation(nil) {
                guard let window = UIApplication.shared.windows.first else { return }
                let renderer = UIGraphicsImageRenderer(size: window.bounds.size)
                let image = renderer.image { ctx in
                    window.drawHierarchy(in: window.bounds, afterScreenUpdates: true)
                }
                capturedImage = image
            }
        }
    }
}

struct PotentialRatingView: View {
    let potentialRating: Int

    var body: some View {
        VStack {
            Text("\(potentialRating)")
                .font(.system(size: 45, weight: .bold)) // Match font size with OverallRatingView
                .foregroundColor(.white) // Text color set to white
            
            Text("Potential")
                .font(.system(size: 24, weight: .medium)) // Match font size with OverallRatingView
                .foregroundColor(.white) // Text color set to white
        }
        .padding() // Match padding with OverallRatingView
        .background(Color.black) // Background set to black
        .cornerRadius(10) // Match corner radius with OverallRatingView
        .shadow(color: Color.black.opacity(0.4), radius: 4, x: 0, y: 2) // Match shadow with OverallRatingView
    }
}






struct ImageDetailView_Previews: PreviewProvider {
    static var previews: some View {
        ImageDetailView(docID: "12345", rating: [85, 70, 90, 80, 95, 88, 92], globalImage: UIImage(named: "exampleImage"))
            .previewDevice("iPhone 14")
    }
}
