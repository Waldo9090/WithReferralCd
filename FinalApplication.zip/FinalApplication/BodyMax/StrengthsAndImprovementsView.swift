//
//  StrengthsAndImprovementsView.swift
//  BodyMax
//
//  Created by Aditya Mahna on 8/15/24.
//

import Foundation
import SwiftUI

struct StrengthsAndImprovementsView: View {
    let globalImage: UIImage?
    let strengths: [String] = ["Strong Arms", "Defined Chest"] // Example data
    let areasForImprovement: [String] = ["Leg Strength", "Core Stability"] // Example data

    var body: some View {
        VStack(spacing: 20) {
            if let globalImage = globalImage {
                Image(uiImage: globalImage)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .frame(width: 100, height: 100)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(Color.white, lineWidth: 2))
                    .shadow(radius: 6)
                    .padding()
            }

            Text("Strengths")
                .font(.headline)
                .padding(.top)

            ForEach(strengths, id: \.self) { strength in
                Text(strength)
                    .font(.subheadline)
                    .padding(.vertical, 5)
            }

            Divider()
                .padding(.vertical, 20)

            Text("Areas for Improvement")
                .font(.headline)

            ForEach(areasForImprovement, id: \.self) { area in
                Text(area)
                    .font(.subheadline)
                    .padding(.vertical, 5)
            }

            Spacer()
        }
        .padding()
        .background(Color(UIColor.systemGray6).edgesIgnoringSafeArea(.all))
    }
}

