import SwiftUI
import FirebaseCore
import GoogleSignIn
import Stripe
import SuperwallKit
import UserNotifications

@main
struct BodyMaxApp: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    @StateObject private var globalContent = GlobalContent()
    
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(globalContent)
        }
    }
}

class AppDelegate: NSObject, UIApplicationDelegate {
    
    override init() {
        super.init()
        // Request permissions and schedule notifications when app starts
        checkNotificationAuthorizationAndSchedule()
        scheduleDiscountNotification()
    }
    
    func application(_ application: UIApplication,
                     open url: URL,
                     options: [UIApplication.OpenURLOptionsKey : Any] = [:]) -> Bool {
        return GIDSignIn.sharedInstance.handle(url)
    }

    func application(_ application: UIApplication,
                     didFinishLaunchingWithOptions launchOptions:
                     [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        Superwall.configure(apiKey: "pk_abead12949b3f3af620e2d2af97f2716d19eaa7cd0329646")
        
        FirebaseApp.configure()
        return true
    }
    
    private func checkNotificationAuthorizationAndSchedule() {
        let center = UNUserNotificationCenter.current()
        center.getNotificationSettings { settings in
            if settings.authorizationStatus == .authorized {
                self.scheduleDailyNotification()
            } else {
                // Optionally, handle the case where notifications are not authorized
                print("Notifications are not authorized.")
            }
        }
    }
    
    // Schedule a daily notification
    private func scheduleDailyNotification() {
        let center = UNUserNotificationCenter.current()
        
        // Create the notification content
        let content = UNMutableNotificationContent()
        content.title = "Reminder"
        content.body = "Don't forget to scan your physique today! Track progress daily."
        content.sound = .default
        
        // Configure the trigger to fire daily at 5 PM
        var dateComponents = DateComponents()
        dateComponents.hour = 18  // 5 PM
        dateComponents.minute = 0
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
        
        // Create the request
        let request = UNNotificationRequest(identifier: "dailyReminder", content: content, trigger: trigger)
        
        // Schedule the notification
        center.add(request) { error in
            if let error = error {
                print("Error scheduling notification: \(error.localizedDescription)")
            }
        }
    }
    
    // Schedule a notification 2 days after the app is installed, and every day after that at 4 PM
    private func scheduleDiscountNotification() {
        let center = UNUserNotificationCenter.current()
        
        // Check when the app was first launched
        let userDefaults = UserDefaults.standard
        let firstLaunchDateKey = "firstLaunchDate"
        
        var firstLaunchDate: Date
        if let savedDate = userDefaults.object(forKey: firstLaunchDateKey) as? Date {
            firstLaunchDate = savedDate
        } else {
            firstLaunchDate = Date()
            userDefaults.set(firstLaunchDate, forKey: firstLaunchDateKey)
        }
        
        // Calculate the trigger date (2 days after first launch at 4 PM)
        let triggerDate = Calendar.current.date(byAdding: .day, value: 1, to: firstLaunchDate) ?? Date()
        var triggerComponents = Calendar.current.dateComponents([.year, .month, .day], from: triggerDate)
        triggerComponents.hour = 16  // 4 PM
        triggerComponents.minute = 0  // 00 minutes
        
        // Create the notification content
        let content = UNMutableNotificationContent()
        content.title = "Too expensive?"
        content.body = "Here's a 40% off."
        content.sound = .default
        
        // Trigger every day after 2 days at 4 PM
        let trigger = UNCalendarNotificationTrigger(dateMatching: triggerComponents, repeats: true)
        
        // Create the request
        let request = UNNotificationRequest(identifier: "discountReminder", content: content, trigger: trigger)
        
        // Schedule the notification
        center.add(request) { error in
            if let error = error {
                print("Error scheduling discount notification: \(error.localizedDescription)")
            }
        }
    }
}
