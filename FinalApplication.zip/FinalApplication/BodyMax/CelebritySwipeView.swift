import SwiftUI

struct CelebritySwipeView: View {
    var celebrities: [Celebrity] = [
        Celebrity(name: "Jake Paul", stats: [85, 75, 80, 82, 70, 72], imageName: "JakePaul"),
        Celebrity(name: "Andrew Tate", stats: [85, 90, 88, 86, 82, 89], imageName: "AndrewTate"),
        Celebrity(name: "Adin Ross", stats: [55, 50, 60, 55, 50, 45], imageName: "AdinRoss"),
        Celebrity(name: "Alex Eubank", stats: [92, 90, 91, 89, 88, 92], imageName: "AlexEubank"),
        Celebrity(name: "Sam Sulek", stats: [92, 90, 94, 93, 88, 91], imageName: "SamSulek"),
        Celebrity(name: "Godzilla", stats: [100, 100, 100, 100, 100, 100], imageName: "GodZilla")
    ]
    
    private var ratingLabels: [String] {
        ["Chest", "Abdominal", "Shoulders", "Arm Definition", "Vascularity/Veins", "Leanness"]
    }
    
    @State private var currentPage: Int = 0
    
    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                VStack {
                    TabView(selection: $currentPage) {
                        // Leaderboard View (Assuming you have this view)
                        LeaderboardView()
                            .tag(0)
                        
                        // Celebrity Views
                        ForEach(celebrities) { celebrity in
                            ScrollView {
                                VStack(spacing: 20) {
                                    // Celebrity Image
                                    Image(celebrity.imageName)
                                        .resizable()
                                        .aspectRatio(contentMode: .fill)
                                        .frame(width: geometry.size.width * 0.6, height: geometry.size.width * 0.6)
                                        .clipShape(Circle())
                                        .overlay(
                                            Circle()
                                                .stroke(Color.primary.opacity(0.1), lineWidth: 4)
                                        )
                                        .shadow(radius: 5)
                                        .padding(.top, 30)
                                    
                                    // Celebrity Name
                                    Text(celebrity.name)
                                        .font(.title2)
                                        .fontWeight(.semibold)
                                        .foregroundColor(.primary)
                                        .padding(.horizontal, 20)
                                        .lineLimit(1)
                                        .truncationMode(.tail)
                                    
                                    // Overall Rating
                                    HStack {
                                        Text("Overall")
                                            .font(.headline)
                                            .fontWeight(.bold)
                                            .foregroundColor(.primary)
                                        Spacer()
                                        Text("\(calculateOverall(for: celebrity))")
                                            .font(.headline)
                                            .fontWeight(.bold)
                                            .foregroundColor(.primary)
                                    }
                                    .padding()
                                    .background(Color(.secondarySystemBackground))
                                    .cornerRadius(12)
                                    .shadow(color: Color.black.opacity(0.1), radius: 4, x: 0, y: 2)
                                    .padding(.horizontal)
                                    
                                    // Ratings
                                    VStack(spacing: 15) {
                                        ForEach(0..<celebrity.stats.count, id: \.self) { index in
                                            RatingRow(label: ratingLabels[index], rating: celebrity.stats[index])
                                        }
                                    }
                                    .padding(.horizontal)
                                    
                                    Spacer()
                                }
                            }
                            .tag(celebrities.firstIndex(of: celebrity)! + 1) // Offset for leaderboard tab
                        }
                    }
                    .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    
                    // Page Indicator Dots
                    HStack(spacing: 6) {
                        ForEach(0..<celebrities.count + 1, id: \.self) { index in
                            Circle()
                                .fill(index == currentPage ? Color.primary : Color.secondary.opacity(0.5))
                                .frame(width: 8, height: 8)
                                .scaleEffect(index == currentPage ? 1.2 : 1.0)
                                .animation(.spring(), value: currentPage)
                        }
                    }
                    .padding(.bottom, 10)
                }
                .background(Color(.systemBackground).edgesIgnoringSafeArea(.all))
            }
            .navigationBarHidden(true)
        }
    }
    
    private func calculateOverall(for celebrity: Celebrity) -> Int {
        guard !celebrity.stats.isEmpty else { return 0 }
        return celebrity.stats.reduce(0, +) / celebrity.stats.count
    }
}

struct Celebrity: Identifiable, Equatable {
    var id = UUID()
    var name: String
    var stats: [Int]
    var imageName: String
}

struct RatingRow: View {
    var label: String
    var rating: Int
    
    var body: some View {
        HStack {
            Text(label)
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(.primary)
            Spacer()
            Text("\(rating)")
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(.primary)
            ProgressBar(value: CGFloat(rating) / 100)
                .frame(width: 100)
        }
        .padding(.vertical, 5)
    }
}

struct ProgressBar: View {
    var value: CGFloat

    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .leading) {
                // Background of the progress bar
                Capsule()
                    .frame(width: geometry.size.width, height: geometry.size.height)
                    .foregroundColor(Color.gray.opacity(0.2))

                // Filled portion of the progress bar
                Capsule()
                    .frame(width: min(value * geometry.size.width, geometry.size.width), height: geometry.size.height)
                    .foregroundColor(.black)
                    .animation(.easeInOut(duration: 0.5), value: value)
            }
        }
        .frame(height: 8)
    }
}

