import SwiftUI

struct WorkoutSelectionView: View {
    @State private var selectedWorkout: String? = nil
    @Environment(\.presentationMode) var presentationMode
    
    // Method to generate haptic feedback
    func generateHapticFeedback() {
        let impactFeedbackGenerator = UIImpactFeedbackGenerator(style: .medium)
        impactFeedbackGenerator.impactOccurred()
    }

    var body: some View {
        VStack {
            // Navigation back button
            HStack {
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.black)
                        .font(.title2) // Increase the size for better visibility
                }
                Spacer()
            }
            .padding()

            // Title and Subtitle
            VStack(spacing: 8) {
                Text("How many workouts do you do per week?")
                    .font(.system(size: 36, weight: .bold)) // Larger, bolder font for emphasis
                    .foregroundColor(.primary) // Use primary color for better contrast

                Text("This will help us design your workout plan")
                    .font(.system(size: 18, weight: .medium)) // Match the style of "Look Better"
                    .foregroundColor(.secondary) // Use secondary color for subtleness
            }
            .padding(.bottom, 40)

            // Workout selection buttons
            VStack(spacing: 16) {
                workoutButton(title: "0-2", selection: $selectedWorkout)
                workoutButton(title: "3-5", selection: $selectedWorkout)
                workoutButton(title: "6+", selection: $selectedWorkout)
            }
            .padding(.horizontal)

            Spacer()

            // Next button
            NavigationLink(destination: HeightWeightSelectionView().navigationBarBackButtonHidden(true)) {
                Text("Next")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(selectedWorkout != nil ? Color.black : Color.gray)
                    .foregroundColor(.white)
                    .font(.system(size: 20, weight: .semibold)) // Larger font for better visibility
                    .cornerRadius(10)
            }
            .simultaneousGesture(TapGesture().onEnded {
                generateHapticFeedback()
            })
            .padding()
            .disabled(selectedWorkout == nil)
        }
        .padding()
        .background(Color(UIColor.systemBackground)) // Background color for better contrast
    }

    // Custom button view for workout options
    private func workoutButton(title: String, selection: Binding<String?>) -> some View {
        Button(action: {
            selection.wrappedValue = title
        }) {
            Text(title)
                .frame(maxWidth: .infinity)
                .padding()
                .background(selection.wrappedValue == title ? Color.black : Color.white)
                .foregroundColor(selection.wrappedValue == title ? .white : .black)
                .font(.system(size: 20, weight: .medium)) // Font size for better readability
                .cornerRadius(10)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(Color.black, lineWidth: 1)
                )
        }
    }
}

struct WorkoutSelectionView_Previews: PreviewProvider {
    static var previews: some View {
        WorkoutSelectionView()
    }
}


