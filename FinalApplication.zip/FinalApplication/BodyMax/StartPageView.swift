import SwiftUI
import SuperwallKit

struct StartPageView: View {
    
    // Method to generate haptic feedback
    func generateHapticFeedback() {
        let impactFeedbackGenerator = UIImpactFeedbackGenerator(style: .medium)
        impactFeedbackGenerator.impactOccurred()
    }

    
    var body: some View {
        VStack {
            // Navigation back button
            HStack {
                Spacer()
            }
            .padding(.horizontal)
            .padding(.top)

            // Logo image
            Image("SwoleAILogo") // Make sure the image name matches your asset catalog
                .resizable()
                .aspectRatio(contentMode: .fit) // Adjust aspect ratio to fit the logo properly
                .frame(width: 200, height: 200) // Adjust size as needed
                .padding(.bottom, 40)

            // Main label
            VStack {
                Text("Swole AI")
                    .font(.system(size: 36, weight: .bold)) // Larger, bolder font for emphasis
                    .foregroundColor(.primary) // Use primary color for better contrast
                    .padding(.bottom, 4)

                Text("Look Better")
                    .font(.system(size: 18, weight: .medium)) // Slightly larger and bolder
                    .foregroundColor(.secondary) // Use secondary color for subtleness
            }
            .padding(.bottom, 60)

            // Get Started button
            NavigationLink(destination: WorkoutSelectionView().navigationBarBackButtonHidden(true)) {
                Text("Get Started")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.black)
                    .foregroundColor(.white)
                    .font(.system(size: 20, weight: .semibold)) // Larger font for better visibility
                    .cornerRadius(12) // Slightly larger corner radius for a softer look
                    .shadow(radius: 5) // Add shadow for a modern effect
            }
            .simultaneousGesture(TapGesture().onEnded {
                generateHapticFeedback()
            })
            .padding(.horizontal)
            .padding(.bottom, 40)
        }
        .padding()
        .background(Color(UIColor.systemBackground)) // Background color for better contrast
        .font(.system(size: 16))
    }
}

struct StartPageView_Previews: PreviewProvider {
    static var previews: some View {
        StartPageView()
    }
}
