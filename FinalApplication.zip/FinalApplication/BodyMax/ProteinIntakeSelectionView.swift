import SwiftUI

struct ProteinIntakeSelectionView: View {
    @State private var selectedIntake: String? = nil
    @State private var navigateToNextView = false
    @Environment(\.presentationMode) var presentationMode
    
    func generateHapticFeedback() {
        let impactFeedbackGenerator = UIImpactFeedbackGenerator(style: .medium)
        impactFeedbackGenerator.impactOccurred()
    }
    
    var body: some View {
        VStack {
            // Navigation back button
            HStack {
                Button(action: {
                    generateHapticFeedback()
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.black)
                }
                Spacer()
            }
            .padding()

            Spacer()

            // Title
            Text("What is your typical protein intake?")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 5)

            // Protein intake selection buttons
            VStack(spacing: 16) {
                Button(action: {
                    generateHapticFeedback()
                    selectedIntake = "Insufficient"
                }) {
                    VStack {
                        Text("Insufficient")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(selectedIntake == "Insufficient" ? Color.black : Color.white)
                            .foregroundColor(selectedIntake == "Insufficient" ? .white : .black)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        
                        Text("0-30 grams of protein")
                            .font(.footnote)
                            .foregroundColor(.gray)
                            .padding(.top, 5)
                    }
                }

                Button(action: {
                    generateHapticFeedback()
                    selectedIntake = "Moderate"
                }) {
                    VStack {
                        Text("Moderate")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(selectedIntake == "Moderate" ? Color.black : Color.white)
                            .foregroundColor(selectedIntake == "Moderate" ? .white : .black)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        
                        Text("40-70 grams of protein")
                            .font(.footnote)
                            .foregroundColor(.gray)
                            .padding(.top, 5)
                    }
                }

                Button(action: {
                    generateHapticFeedback()
                    selectedIntake = "Plentiful"
                }) {
                    VStack {
                        Text("Plentiful")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(selectedIntake == "Plentiful" ? Color.black : Color.white)
                            .foregroundColor(selectedIntake == "Plentiful" ? .white : .black)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        
                        Text("70-100 grams of protein")
                            .font(.footnote)
                            .foregroundColor(.gray)
                            .padding(.top, 5)
                    }
                }

                Button(action: {
                    generateHapticFeedback()
                    selectedIntake = "Exceptional"
                }) {
                    VStack {
                        Text("Exceptional")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(selectedIntake == "Exceptional" ? Color.black : Color.white)
                            .foregroundColor(selectedIntake == "Exceptional" ? .white : .black)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        
                        Text("100+ grams of protein")
                            .font(.footnote)
                            .foregroundColor(.gray)
                            .padding(.top, 5)
                    }
                }
            }
            .padding(.horizontal)

            Spacer()

            // Next button
            NavigationLink(destination: ActivityLevelSelectionView().navigationBarHidden(true), isActive: $navigateToNextView) {
                Button(action: {
                    generateHapticFeedback()
                    navigateToNextView = true
                }) {
                    Text("Next")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(selectedIntake != nil ? Color.black : Color.gray)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()
                .disabled(selectedIntake == nil)
            }
        }
        .navigationBarHidden(true)
    }
}

struct ProteinIntakeSelectionView_Previews: PreviewProvider {
    static var previews: some View {
        ProteinIntakeSelectionView()
    }
}

