import SwiftUI

struct BirthdateSelectionView: View {
    @State private var selectedMonth = 1
    @State private var selectedDay = 1
    @State private var selectedYear = 2024
    @Environment(\.presentationMode) var presentationMode
    
    func generateHapticFeedback() {
        let impactFeedbackGenerator = UIImpactFeedbackGenerator(style: .medium)
        impactFeedbackGenerator.impactOccurred()
    }
    
    let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    let days = Array(1...31)
    let years = Array(1900...2024).reversed().map { "\($0)" }

    var body: some View {
        VStack {
            // Navigation back button
            HStack {
                Button(action: {
                    generateHapticFeedback()
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.black)
                }
                Spacer()
            }
            .padding()

            // Title
            Text("When were you born?")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.top, 20)
                .padding(.bottom, 20)

            // Date selection
            VStack {
                HStack {
                    Picker("Month", selection: $selectedMonth) {
                        ForEach(0..<months.count) { index in
                            Text(months[index]).tag(index + 1)
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                    .frame(width: 150, height: 100)
                    .clipped()
                    .onChange(of: selectedMonth) { _ in
                        generateHapticFeedback()
                    }

                    Picker("Day", selection: $selectedDay) {
                        ForEach(days, id: \.self) { day in
                            Text("\(day)").tag(day)
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                    .frame(width: 100, height: 100)
                    .clipped()
                    .onChange(of: selectedDay) { _ in
                        generateHapticFeedback()
                    }

                    Picker("Year", selection: $selectedYear) {
                        ForEach(years, id: \.self) { year in
                            Text(year).tag(Int(year)!)
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                    .frame(width: 100, height: 100)
                    .clipped()
                    .onChange(of: selectedYear) { _ in
                        generateHapticFeedback()
                    }
                }
                .padding(.bottom, 20)
            }

            Spacer()

            // Next button
            NavigationLink(destination: ProteinIntakeSelectionView().navigationBarHidden(true)) {
                Text("Next")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.black)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding()
            .simultaneousGesture(TapGesture().onEnded {
                generateHapticFeedback()
            })
        }
        .navigationTitle("")
        .navigationBarHidden(false) // Ensure navigation bar is visible on iPad
    }
}

struct BirthdateSelectionView_Previews: PreviewProvider {
    static var previews: some View {
        BirthdateSelectionView()
    }
}

