import SwiftUI

struct ActivityLevelSelectionView: View {
    @State private var selectedActivity: String? = nil
    @State private var navigateToNextView = false
    @Environment(\.presentationMode) var presentationMode
    
    func generateHapticFeedback() {
        let impactFeedbackGenerator = UIImpactFeedbackGenerator(style: .medium)
        impactFeedbackGenerator.impactOccurred()
    }
    
    var body: some View {
        VStack {
            // Navigation back button
            HStack {
                Button(action: {
                    generateHapticFeedback()
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.black)
                }
                Spacer()
            }
            .padding()

            Spacer()

            // Title
            Text("What is your activity level?")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 5)

            // Activity level selection buttons
            VStack(spacing: 16) {
                Button(action: {
                    generateHapticFeedback()
                    selectedActivity = "Sedentary"
                }) {
                    VStack {
                        Text("Sedentary")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(selectedActivity == "Sedentary" ? Color.black : Color.white)
                            .foregroundColor(selectedActivity == "Sedentary" ? .white : .black)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        
                        Text("Little to no exercise")
                            .font(.footnote)
                            .foregroundColor(.gray)
                            .padding(.top, 5)
                    }
                }

                Button(action: {
                    generateHapticFeedback()
                    selectedActivity = "Lightly Active"
                }) {
                    VStack {
                        Text("Lightly Active")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(selectedActivity == "Lightly Active" ? Color.black : Color.white)
                            .foregroundColor(selectedActivity == "Lightly Active" ? .white : .black)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        
                        Text("Light exercise 1-3 days a week")
                            .font(.footnote)
                            .foregroundColor(.gray)
                            .padding(.top, 5)
                    }
                }

                Button(action: {
                    generateHapticFeedback()
                    selectedActivity = "Moderately Active"
                }) {
                    VStack {
                        Text("Moderately Active")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(selectedActivity == "Moderately Active" ? Color.black : Color.white)
                            .foregroundColor(selectedActivity == "Moderately Active" ? .white : .black)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        
                        Text("Moderate exercise 3-5 days a week")
                            .font(.footnote)
                            .foregroundColor(.gray)
                            .padding(.top, 5)
                    }
                }

                Button(action: {
                    generateHapticFeedback()
                    selectedActivity = "Very Active"
                }) {
                    VStack {
                        Text("Very Active")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(selectedActivity == "Very Active" ? Color.black : Color.white)
                            .foregroundColor(selectedActivity == "Very Active" ? .white : .black)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        
                        Text("Hard exercise 6-7 days a week")
                            .font(.footnote)
                            .foregroundColor(.gray)
                            .padding(.top, 5)
                    }
                }

                Button(action: {
                    generateHapticFeedback()
                    selectedActivity = "Super Active"
                }) {
                    VStack {
                        Text("Super Active")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(selectedActivity == "Super Active" ? Color.black : Color.white)
                            .foregroundColor(selectedActivity == "Super Active" ? .white : .black)
                            .cornerRadius(10)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.black, lineWidth: 1)
                            )
                        
                        Text("Physical job or intense exercise daily")
                            .font(.footnote)
                            .foregroundColor(.gray)
                            .padding(.top, 5)
                    }
                }
            }
            .padding(.horizontal)

            Spacer()

            // Next button
            NavigationLink(destination: ReferralCodeView().navigationBarHidden(true), isActive: $navigateToNextView) {
                Button(action: {
                    generateHapticFeedback()
                    navigateToNextView = true
                }) {
                    Text("Next")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(selectedActivity != nil ? Color.black : Color.gray)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding()
                .disabled(selectedActivity == nil)
            }
        }
        .navigationBarHidden(true)
    }
}

struct ActivityLevelSelectionView_Previews: PreviewProvider {
    static var previews: some View {
        ActivityLevelSelectionView()
    }
}
