import SwiftUI
import WebKit
import FirebaseFirestore

struct Exercise: Identifiable, Decodable {
    @DocumentID var id: String?
    var name: String
    var instructions: [String]
    var reps: String
    var sets: Int
}

func getSavedWorkouts(key: String) -> [[Int]]? {
    guard let data = UserDefaults.standard.data(forKey: key) else {
        print("No data found for key: \(key)")
        return nil
    }
    
    let decoder = JSONDecoder()
    do {
        let workouts = try decoder.decode([[Int]].self, from: data)
        return workouts
    } catch {
        print("Failed to decode workouts: \(error)")
        return nil
    }
}

func fetchExercises(workout: [Int], completion: @escaping ([Exercise]?) -> Void) {
    let db = Firestore.firestore()
    let exercisesRef = db.collection("exercises2.0")
    
    let exerciseIds = workout.map { String($0) }
    
    print("Fetching exercises for IDs: \(exerciseIds)")
    
    let dispatchGroup = DispatchGroup()
    var exercises: [Exercise] = []
    var fetchError: Error?
    
    for id in exerciseIds {
        dispatchGroup.enter()
        exercisesRef.document(id).getDocument { document, error in
            if let error = error {
                fetchError = error
                print("Error fetching exercise with ID \(id): \(error)")
            } else if let document = document, document.exists {
                if let exercise = try? document.data(as: Exercise.self) {
                    exercises.append(exercise)
                } else {
                    print("Error decoding exercise with ID \(id)")
                }
            } else {
                print("No exercise found with ID \(id)")
            }
            dispatchGroup.leave()
        }
    }
    
    dispatchGroup.notify(queue: .main) {
        if let error = fetchError {
            completion(nil)
        } else {
            print("Fetched exercises: \(exercises)")
            completion(exercises)
        }
    }
}

struct WorkoutPlanView: View {
    @State private var exercises: [[Exercise]] = []
    @State private var loading = true
    @State private var selectedExercise: Exercise? = nil
    @State private var showingInstructions = false

    let weekdays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    let backgroundColor = Color(UIColor.systemBackground)
    let cardColor = Color(UIColor.secondarySystemBackground)
    let accentColor = Color.black

    var body: some View {
        VStack {
            if loading {
                ProgressView("Loading workouts...")
                    .progressViewStyle(CircularProgressViewStyle(tint: accentColor))
                    .scaleEffect(1.5)
                    .padding()
            } else if exercises.isEmpty {
                // Display message when no exercises are available
                Text("Your custom workout plan will show up here after your first scan.")
                    .font(.title2)
                    .fontWeight(.medium)
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.center)
                    .padding()
            } else {
                ScrollView {
                    ForEach(exercises.indices, id: \.self) { index in
                        VStack(alignment: .leading, spacing: 10) {
                            Text(weekdays[index % weekdays.count])
                                .font(.title2)
                                .fontWeight(.bold)
                                .padding(.bottom, 10)
                                .foregroundColor(accentColor)
                            
                            ForEach(exercises[index]) { exercise in
                                VStack(spacing: 12) {
                                    HStack {
                                        VStack(alignment: .leading, spacing: 5) {
                                            Text(exercise.name)
                                                .font(.headline)
                                                .fontWeight(.medium)
                                                .foregroundColor(.primary)
                                            HStack(spacing: 20) {
                                                Text("Reps: \(exercise.reps)")
                                                    .font(.subheadline)
                                                    .foregroundColor(.gray)
                                                Text("Sets: \(exercise.sets)")
                                                    .font(.subheadline)
                                                    .foregroundColor(.gray)
                                            }
                                        }
                                        Spacer()
                                        Button(action: {
                                            withAnimation {
                                                selectedExercise = exercise
                                                showingInstructions = true
                                            }
                                        }) {
                                            Image(systemName: "chevron.right.circle.fill")
                                                .font(.system(size: 24))
                                                .foregroundColor(accentColor)
                                        }
                                        .sheet(item: $selectedExercise) { exercise in
                                            ExerciseDetailView(exercise: exercise)
                                        }
                                    }
                                    .padding(.horizontal)
                                    .padding(.vertical, 10)
                                    .background(RoundedRectangle(cornerRadius: 10).fill(cardColor))
                                    .shadow(radius: 5)
                                }
                                .padding(.horizontal)
                                .padding(.top, 10)
                            }
                        }
                        .padding(.horizontal)
                        .padding(.top, 10)
                    }
                }
                .transition(.opacity)
            }
        }
        .background(backgroundColor)
        .onAppear {
            loadWorkouts()
        }
    }

    func loadWorkouts() {
        guard let savedWorkouts = getSavedWorkouts(key: "savedWorkoutPlan") else {
            loading = false
            return
        }

        let dispatchGroup = DispatchGroup()
        var allExercises: [[Exercise]] = []

        for workout in savedWorkouts {
            dispatchGroup.enter()
            fetchExercises(workout: workout) { fetchedExercises in
                if let exercises = fetchedExercises {
                    allExercises.append(exercises)
                } else {
                    print("Failed to fetch exercises for workout: \(workout)")
                }
                dispatchGroup.leave()
            }
        }

        dispatchGroup.notify(queue: .main) {
            withAnimation {
                self.exercises = allExercises
                self.loading = false
            }
        }
    }
}




struct ExerciseDetailView: View {
    var exercise: Exercise
    
    @Environment(\.dismiss) private var dismiss

    let backgroundColor = Color(UIColor.systemBackground)
    let titleColor = Color.black
    let instructionColor = Color.gray
    let gradient = LinearGradient(gradient: Gradient(colors: [Color.white, Color(UIColor.systemGray6)]), startPoint: .top, endPoint: .bottom)
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // Exercise Name with a custom font and fade-in animation
                    Text(exercise.name)
                        .font(.custom("Avenir-Heavy", size: 32))
                        .foregroundColor(titleColor)
                        .padding(.bottom, 10)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .transition(.opacity)
                        .animation(.easeInOut(duration: 0.8), value: exercise.name)
                    
                    Divider()
                    
                    // Instructions Header with slide-in animation
                    Text("Instructions")
                        .font(.custom("Avenir-Medium", size: 24))
                        .foregroundColor(titleColor)
                        .padding(.bottom, 5)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .transition(.move(edge: .leading))
                        .animation(.easeInOut(duration: 0.8), value: exercise.name)
                    
                    // Instruction List with a slight delay in slide-in animation for each instruction
                    VStack(alignment: .leading, spacing: 15) {
                        ForEach(exercise.instructions.indices, id: \.self) { index in
                            HStack(alignment: .top) {
                                Image(systemName: "circle.fill")
                                    .font(.system(size: 8))
                                    .foregroundColor(instructionColor)
                                    .padding(.top, 6)
                                
                                Text(exercise.instructions[index])
                                    .font(.custom("Avenir-Light", size: 18))
                                    .foregroundColor(instructionColor)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .transition(.move(edge: .trailing))
                                    .animation(.easeInOut(duration: 0.6).delay(Double(index) * 0.1), value: exercise.instructions)
                            }
                        }
                    }
                    
                    Spacer()
                }
                .padding()
                .background(gradient)
                .cornerRadius(12)
                .shadow(color: .gray.opacity(0.3), radius: 10, x: 0, y: 5)
                .padding()
            }
            .background(backgroundColor.edgesIgnoringSafeArea(.all))
            .navigationBarItems(trailing: Button(action: {
                withAnimation(.easeInOut) {
                    dismiss()
                }
            }) {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 24))
                    .foregroundColor(titleColor)
                    .transition(.scale)
            })
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                withAnimation(.easeIn(duration: 0.5)) {
                    // Additional appearance animations can be added here
                }
            }
        }
    }
}

