import SwiftUI
import UIKit
import Firebase

extension NSNotification.Name {
    static let userDidLogout = Notification.Name("userDidLogout")
    static let analysisStarted = Notification.Name("analysisStarted")
}


struct UploadPictureView: View {
    @Binding var reset: Bool
    @StateObject private var authManager = AuthManager()
    @State private var showActionSheet = false
    @State private var selectedImage: UIImage?
    @State private var showImagePicker = false
    @State private var imagePickerSource: UIImagePickerController.SourceType = .photoLibrary
    @State private var showSettingsMenu = false
    @State private var showLogoutConfirmation = false
    @State private var showDeleteAccountConfirmation = false
    @State private var navigateToStartPage = false
    @State private var showSurvey = false
    @State private var surveyResponse = ""
    @State private var selectedReason = ""
    @State private var otherReason = ""

    private let termsOfUseURL = URL(string: "https://www.apple.com/legal/internet-services/itunes/dev/stdeula/")!
    private let privacyPolicyURL = URL(string: "https://waldo9090.github.io/Privacy-Policy/")!

    func generateHapticFeedback() {
        let impactFeedbackGenerator = UIImpactFeedbackGenerator(style: .medium)
        impactFeedbackGenerator.impactOccurred()
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                Text("Upload a Body Picture")
                    .font(.title2)
                    .fontWeight(.bold)
                    .padding(.top, 20)
                    .multilineTextAlignment(.center)
                
                Text("With the selfie camera, take a picture of your upper body")
                    .font(.body)
                    .foregroundColor(.gray)
                    .padding(.bottom, 20)
                    .padding(.horizontal)
                    .multilineTextAlignment(.center)
                
                Image(uiImage: selectedImage ?? UIImage(named: "BodyImage")!)
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity, maxHeight: 300)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(12)
                    .padding(.horizontal)
                
                Button(action: {
                    generateHapticFeedback()
                    showActionSheet = true
                }) {
                    Text(selectedImage != nil ? "Use Another" : "Upload or Take a Picture")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.black)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding(.horizontal)
                .padding(.bottom, 20)
                .actionSheet(isPresented: $showActionSheet) {
                    ActionSheet(title: Text("Select Photo"), message: nil, buttons: [
                        .default(Text("Take a Picture")) {
                            generateHapticFeedback()
                            imagePickerSource = .camera
                            showImagePicker = true
                        },
                        .default(Text("Choose an Existing Image")) {
                            generateHapticFeedback()
                            imagePickerSource = .photoLibrary
                            showImagePicker = true
                        },
                        .cancel()
                    ])
                }
                .sheet(isPresented: $showImagePicker) {
                    ImagePicker(sourceType: imagePickerSource, selectedImage: $selectedImage)
                }

                if selectedImage != nil {
                    Button(action: {
                        generateHapticFeedback()
                        NotificationCenter.default.post(name: .analysisStarted, object: nil)
                        navigateToStartPage = true
                    }) {
                        Text("Continue")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.black)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 20)
                }
            }
            .navigationTitle("Upload Picture")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(true)
            .navigationBarItems(trailing: settingsButton)
            .background(Color.white.ignoresSafeArea())
            .onChange(of: reset) { newValue in
                if newValue {
                    selectedImage = nil
                }
            }
        }
        .tabBarHidden(false)
    }

    private var settingsButton: some View {
        Button(action: {
            generateHapticFeedback()
            showSettingsMenu.toggle()
        }) {
            Image(systemName: "gearshape")
                .font(.title2)
                .padding()
        }
        .actionSheet(isPresented: $showSettingsMenu) {
            ActionSheet(title: Text("Settings"), buttons: [
                .destructive(Text("Delete Account")) {
                    generateHapticFeedback()
                    showLogoutConfirmation = true
                },
                .cancel()
            ])
        }
        .sheet(isPresented: $showLogoutConfirmation) {
            VStack {
                if !showSurvey {
                    // Original account deletion confirmation UI
                    Text("Are you sure you want to delete your account?")
                        .font(.headline)
                        .padding()
                    HStack {
                        Button("Cancel") {
                            generateHapticFeedback()
                            showLogoutConfirmation = false
                        }
                        .padding()
                        Button("Delete Account") {
                            generateHapticFeedback()
                            showSurvey = true
                        }
                        .padding()
                    }
                } else {
                    // Improved Survey UI
                    Text("Why are you leaving?")
                        .font(.headline)
                        .padding()

                    Picker("Select a reason", selection: $selectedReason) {
                        Text("Price").tag("Price")
                        Text("Inaccuracy").tag("Inaccuracy")
                        Text("Workout Plan").tag("Workout Plan")
                        Text("Other").tag("Other")
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding()

                    if selectedReason == "Other" {
                        TextField("Please specify", text: $otherReason)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding()
                    }

                    Text("How can we improve?")
                        .font(.headline)
                        .padding()

                    TextField("Your response", text: $surveyResponse)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .padding()

                    HStack {
                        Button("Submit") {
                            generateHapticFeedback()
                            saveSurveyResponse()
                            authManager.signOut()
                            showLogoutConfirmation = false
                            navigateToStartPage = true

                            NotificationCenter.default.post(name: .userDidLogout, object: nil)
                        }
                        .padding()

                        Button("Skip") {
                            generateHapticFeedback()
                            authManager.signOut()
                            showLogoutConfirmation = false
                            navigateToStartPage = true
                            NotificationCenter.default.post(name: .userDidLogout, object: nil)
                        }
                        .padding()
                    }
                }
            }
        }
    }

    private func saveSurveyResponse() {
        
        let userDefaults = UserDefaults.standard
        guard let email = UserDefaults.standard.string(forKey: "email") else {
            print("No email found in UserDefaults.")
            return
        }
        
        let db = Firestore.firestore()
        let surveyData: [String: Any] = [
            "email": email ?? "",
            "reason": selectedReason,
            "otherReason": otherReason,
            "improvementSuggestion": surveyResponse,
            "timestamp": Timestamp()
        ]
        
        db.collection("surveyResponses").addDocument(data: surveyData) { error in
            if let error = error {
                print("Error saving survey response: \(error.localizedDescription)")
            } else {
                print("Survey response saved successfully.")
            }
        }
    }
}


extension View {
    func tabBarHidden(_ hidden: Bool) -> some View {
        self.modifier(TabBarModifier(isHidden: hidden))
    }
}

struct TabBarModifier: ViewModifier {
    let isHidden: Bool

    func body(content: Content) -> some View {
        ZStack {
            content
            if isHidden {
                VStack {
                    Spacer()
                    Divider()
                        .opacity(0)
                }
            }
        }
    }
}

struct ImagePicker: UIViewControllerRepresentable {
    var sourceType: UIImagePickerController.SourceType
    @Binding var selectedImage: UIImage?
    
    @EnvironmentObject var globalContent: GlobalContent

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = sourceType
        picker.delegate = context.coordinator
        
        if sourceType == .camera {
            picker.cameraDevice = .front
        }

        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    class Coordinator: NSObject, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        var parent: ImagePicker

        init(_ parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.originalImage] as? UIImage {
                parent.selectedImage = image
                if let imageData = image.pngData() {
                    parent.globalContent.globalImage = imageData // Save image to GlobalContent
                }
            }
            picker.dismiss(animated: true, completion: nil)
        }

        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true, completion: nil)
        }
    }
}
