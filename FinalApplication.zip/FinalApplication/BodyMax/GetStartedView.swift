import SwiftUI

struct GetStartedView: View {
    @State private var resetUploadPicture: Bool = false

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                // Image at the top
                Image("BodyImage") // Replace with your image name
                    .resizable()
                    .scaledToFit()
                    .frame(height: 150) // Adjust height as needed

                // Welcome message
                VStack {
                    Text("Welcome!")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .padding(.bottom, 5)
                    
                    Text("You're all set to get started with our app.")
                        .font(.body)
                        .foregroundColor(.gray)
                        .padding(.bottom, 10) // Reduce bottom padding
                }
                .padding(.horizontal, 20) // Optional horizontal padding for text

                // Get Started button
                NavigationLink(destination: UploadPictureView(reset: $resetUploadPicture).navigationBarHidden(true)) {
                    Text("Get Started")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.black)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
                .padding(.horizontal, 20) // Adjust horizontal padding if needed
                .padding(.bottom, 10) // Adjust bottom padding
            }
            .navigationTitle("Get Started")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

struct GetStartedView_Previews: PreviewProvider {
    static var previews: some View {
        GetStartedView()
    }
}

