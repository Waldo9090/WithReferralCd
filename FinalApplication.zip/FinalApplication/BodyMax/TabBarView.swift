import SwiftUI
import SuperwallKit

struct TabBarView: View {
    @Binding var selectedTab: Int
    @State private var resetUploadPicture: Bool = false
    @State private var showTabBarView: Bool = true
    @State private var userLogout: Bool = false

    @EnvironmentObject var globalContent: GlobalContent

    var body: some View {
        if showTabBarView {
            TabView(selection: $selectedTab) {
                UploadPictureView(reset: $resetUploadPicture)
                    .tabItem {
                        Image(systemName: "camera")
                            .font(.title2)
                        Text("Scan")
                            .font(.caption)
                    }
                    .tag(0)

                HistoryView()
                    .tabItem {
                        Image(systemName: "chart.bar")
                            .font(.title2)
                        Text("Progress")
                            .font(.caption)
                    }
                    .tag(1)

                CelebritySwipeView()
                    .tabItem {
                        Image(systemName: "rectangle.3.group")
                            .font(.title2)
                        Text("Compare")
                            .font(.caption)
                    }
                    .tag(2)

                WorkoutPlanView()
                    .tabItem {
                        Image(systemName: "list.dash")
                            .font(.title2)
                        Text("Workout")
                            .font(.caption)
                    }
                    .tag(3)
            }
            .background(Color.black.edgesIgnoringSafeArea(.bottom))
            .tabViewStyle(DefaultTabViewStyle())
            .onChange(of: resetUploadPicture) { _ in
                resetUploadPicture = false
            }
            
            .onChange(of: selectedTab) { newTab in
                if newTab != 0 { // Do not trigger paywall if "Upload Picture" tab is selected
                    Superwall.shared.register(event: "discount_trigger")
                }
            }
            .onReceive(NotificationCenter.default.publisher(for: .analysisStarted)) { _ in
                print("Received analysisStarted notification")
                showTabBarView = false
            }
            .onReceive(NotificationCenter.default.publisher(for: .userDidLogout)) { _ in
                print("Received userDidLogout notification")
                showTabBarView = false
                userLogout = true
            }
            .onReceive(NotificationCenter.default.publisher(for: .analysisComplete)) { _ in
                print("Received analysisComplete notification")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    selectedTab = 1
                }
                selectedTab = 1
            }
        } else {
            if userLogout {
                StartPageView()
            } else {
                if let imageData = globalContent.globalImage, let uiImage = UIImage(data: imageData) {
                    AnalysisPage(selectedImage: uiImage)
                } else {
                    Text("No image available")
                }
            }
        }
    }
}
