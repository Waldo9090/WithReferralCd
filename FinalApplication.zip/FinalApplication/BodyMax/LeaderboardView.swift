import SwiftUI
import FirebaseFirestore
import FirebaseAuth
import Combine

struct LeaderboardView: View {
    @EnvironmentObject var globalContent: GlobalContent
    @State private var username: String = ""
    @State private var leaderboard: [LeaderboardEntry] = []
    @State private var isFetchingUser: Bool = true
    @State private var hasCompletedSteps: Bool = false
    @State private var showErrorMessage: Bool = false // Updated for username validation

    var body: some View {
        ZStack {
            Color.white
                .edgesIgnoringSafeArea(.all)

            if isFetchingUser {
                ProgressView()
                    .progressViewStyle(CircularProgressViewStyle(tint: .black))
                    .scaleEffect(1.5)
                    .onAppear {
                        fetchUsernameAndLeaderboard()
                    }
            } else if !hasCompletedSteps {
                VStack(spacing: 20) {
                    // Username input section
                    Text("Create a Username")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.black)

                    Text("Enter a username to view your rank on the leaderboard.")
                        .font(.body)
                        .foregroundColor(.gray)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 40)

                    TextField("Username", text: $username)
                        .padding()
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(10)
                        .foregroundColor(.black)
                        .padding(.horizontal, 32)

                    // Error message if username is empty
                    if showErrorMessage {
                        Text("Username cannot be empty.")
                            .font(.body)
                            .foregroundColor(.red)
                            .padding(.horizontal, 32)
                            .multilineTextAlignment(.center)
                    }

                    // Continue button
                    Button(action: continueToLeaderboard) {
                        Text("Continue")
                            .font(.headline)
                            .padding()
                            .frame(maxWidth: .infinity)
                            .background(!username.isEmpty ? Color.green : Color.gray)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding(.horizontal, 32)
                    .disabled(username.isEmpty) // Disable button if username is empty
                }
                .padding()
                .background(Color.white)
                .cornerRadius(12)
                .shadow(color: Color.black.opacity(0.1), radius: 10, x: 0, y: 5)
                .padding(.horizontal, 32)
            } else {
                // Display leaderboard after all conditions are met
                VStack(spacing: 20) {
                    Text("Leaderboard")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                        .padding(.top)

                    List {
                        ForEach(0..<leaderboard.count, id: \.self) { index in
                            let entry = leaderboard[index]
                            HStack {
                                Text("#\(index + 1)")
                                    .font(.headline)
                                    .foregroundColor(.gray)
                                    .frame(width: 50, alignment: .leading)
                                VStack(alignment: .leading) {
                                    Text(entry.username)
                                        .font(.headline)
                                        .foregroundColor(.black)
                                    Text("Score: \(entry.overall)")
                                        .font(.subheadline)
                                        .foregroundColor(.gray)
                                }
                                Spacer()
                            }
                            .padding()
                            .background(Color.white)
                            .cornerRadius(8)
                            .shadow(color: Color.black.opacity(0.05), radius: 5, x: 0, y: 2)
                        }
                    }
                    .listStyle(PlainListStyle())
                    .padding(.horizontal, -20)
                }
                .padding()
            }
        }
    }

    // Function to fetch username and leaderboard if needed
    private func fetchUsernameAndLeaderboard() {
        let userDefaults = UserDefaults.standard
        guard let email = userDefaults.string(forKey: "email") else {
            print("No email found in UserDefaults.")
            isFetchingUser = false
            return
        }

        let db = Firestore.firestore()

        db.collection("leaderboard")
            .document(email)
            .getDocument { document, error in
                if let error = error {
                    print("Error fetching user document: \(error)")
                    isFetchingUser = false
                    return
                }

                if let document = document, document.exists {
                    let data = document.data()
                    if let username = data?["username"] as? String {
                        globalContent.username = username
                        print("Fetched username from Firestore: \(username)")
                        fetchLeaderboard()
                        isFetchingUser = false
                        hasCompletedSteps = true
                    } else {
                        isFetchingUser = false
                    }
                } else {
                    isFetchingUser = false
                }
            }
    }

    // Function to save username and proceed to leaderboard
    private func continueToLeaderboard() {
        if !username.trimmingCharacters(in: .whitespaces).isEmpty {
            // Save the username to Firestore and proceed to leaderboard
            saveUsername()
            hasCompletedSteps = true
            showErrorMessage = false
        } else {
            // Show error message if username is empty
            showErrorMessage = true
        }
    }

    // Function to save username to Firestore
    private func saveUsername() {
        guard let email = UserDefaults.standard.string(forKey: "email") else {
            print("No email found in UserDefaults.")
            return
        }

        globalContent.username = username
        globalContent.addToLeaderboard()

        let db = Firestore.firestore()

        db.collection("leaderboard")
            .document(email)
            .setData(["username": username], merge: true) { error in
                if let error = error {
                    print("Error saving username to Firestore: \(error)")
                } else {
                    print("Username successfully saved to Firestore.")
                    fetchLeaderboard()
                }
            }
    }

    // Function to fetch leaderboard data
    private func fetchLeaderboard() {
        let db = Firestore.firestore()
        db.collection("leaderboard")
            .order(by: "overall", descending: true)
            .getDocuments { snapshot, error in
                if let error = error {
                    print("Error fetching leaderboard: \(error)")
                    return
                }

                var entries: [LeaderboardEntry] = []
                snapshot?.documents.forEach { document in
                    let data = document.data()
                    if let username = data["username"] as? String,
                       let overall = data["overall"] as? Int,
                       overall > 0 {
                        entries.append(LeaderboardEntry(username: username, overall: overall))
                    }
                }

                self.leaderboard = entries
            }
    }
}

struct LeaderboardEntry: Identifiable, Equatable {
    let id = UUID()
    let username: String
    let overall: Int
}

