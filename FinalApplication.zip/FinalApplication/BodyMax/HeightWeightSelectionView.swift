import SwiftUI

struct HeightWeightSelectionView: View {
    @State private var selectedHeightFt: Int = 5
    @State private var selectedHeightIn: Int = 8
    @State private var selectedWeight: Int = 150
    @Environment(\.presentationMode) var presentationMode
    
    
    func generateHapticFeedback() {
        let impactFeedbackGenerator = UIImpactFeedbackGenerator(style: .medium)
        impactFeedbackGenerator.impactOccurred()
    }
    
    
    var body: some View {
        VStack {
            // Navigation back button
            HStack {
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.black)
                }
                Spacer()
            }        
            .padding()

            // Title
            Text("Height and Weight")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.top, 20)
                .padding(.bottom, 20)

            // Height selection
            VStack {
                Text("Height")
                    .font(.headline)
                    .padding(.bottom, 10)

                HStack {
                    Picker(selection: $selectedHeightFt, label: Text("Feet")) {
                        ForEach(4..<8) { ft in
                            Text("\(ft) ft").tag(ft)
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                    .frame(width: 100, height: 100)
                    .clipped()

                    Picker(selection: $selectedHeightIn, label: Text("Inches")) {
                        ForEach(1..<13) { inch in
                            Text("\(inch) in").tag(inch)
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                    .frame(width: 100, height: 100)
                    .clipped()
                }
                .padding(.bottom, 20)
            }

            // Weight selection
            VStack {
                Text("Weight")
                    .font(.headline)
                    .padding(.bottom, 10)

                Picker(selection: $selectedWeight, label: Text("Pounds")) {
                    ForEach(50..<400) { lb in
                        Text("\(lb) lbs").tag(lb)
                    }
                }
                .pickerStyle(WheelPickerStyle())
                .frame(height: 100)
                .clipped()
            }

            Spacer()

            // Next button
            NavigationLink(destination: BirthdateSelectionView().navigationBarBackButtonHidden(true)) {
                Text("Next")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.black)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .simultaneousGesture(TapGesture().onEnded {
                generateHapticFeedback()
            })
            .padding()
        }
    }
}

struct HeightWeightSelectionView_Previews: PreviewProvider {
    static var previews: some View {
        HeightWeightSelectionView()
    }
}

