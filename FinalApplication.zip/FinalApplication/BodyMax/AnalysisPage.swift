import SwiftUI

import Foundation
import SuperwallKit

func parseMatrix(from matrixString: String) -> [[Int]]? {
    // Remove outer brackets and any extra spaces
    // Step 1: Split the string into rows
    
    let trimmedString = matrixString.trimmingCharacters(in: .whitespacesAndNewlines)

    let rows = trimmedString.split(separator: "\n")

    // Step 2: Convert each row into an array of integers
    let array2D = rows.map { row -> [Int] in
        return row.split(separator: ", ").compactMap { Int($0) }
    }
    return array2D
    
}


func checkSubscription(customerId: String, completion: @escaping (Bool) -> Void) {
    guard let url = URL(string: "https://swoleai-backend.onrender.com/check-subscription") else {
        completion(false)
        return
    }

    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.setValue("application/json", forHTTPHeaderField: "Content-Type")

    let body = ["customerId": customerId]
    request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [])

    let task = URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            print("Error: \(error)")
            completion(false)
            return
        }

        guard let data = data else {
            completion(false)
            return
        }

        do {
            if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Bool] {
                // Extract `hasActiveSubscription` from the JSON response
                if let hasActiveSubscription = json["hasActiveSubscription"] {
                    completion(hasActiveSubscription)
                } else {
                    completion(false)
                }
            }
        } catch {
            print("JSON Error: \(error)")
            completion(false)
        }
    }

    task.resume()
}



import SwiftUI

// Define a custom error type
enum AnalyzeImageError: Error {
    case lightingIssue
    case imageAnalysisFailed(Error)
    case textAnalysisFailed(Error)
    case workoutPlanGenerationFailed
    case encodingError
    case requestError(Error)
    case noData
    case jsonParsingError(Error)
    case maxRetriesReached

}

func saveWorkoutToUserDefaults(workout: [[Int]], key: String) {
    let encoder = JSONEncoder()
    do {
        let data = try encoder.encode(workout)
        UserDefaults.standard.set(data, forKey: key)
    } catch {
        print("Failed to encode workout: \(error)")
    }
}

func processImageAndText(image: UIImage, globalContent: GlobalContent, completion: @escaping (Result<String, AnalyzeImageError>) -> Void) {
    
    func analyzeAndGenerateWorkout(image: UIImage, retryCount: Int = 0, maxRetries: Int = 100, completion: @escaping (Result<String, AnalyzeImageError>) -> Void) {
        guard retryCount < maxRetries else {
            completion(.failure(.lightingIssue)) // Define this error case
            return
        }
        
        analyzeImage(image: image) { imageResult in
            switch imageResult {
            case .success(let content):
                let values = content
                    .trimmingCharacters(in: CharacterSet(charactersIn: "[]"))
                    .components(separatedBy: ", ")
                    .compactMap { Int($0) }
                print("VALUES: ", values)
                
                if values.count == 7 {
                    globalContent.content = values
                    globalContent.savedContent = values
                    globalContent.saveRatings()
                    globalContent.addToLeaderboard()
                    
                    generateWorkoutPlan(basedOn: content) { workoutResult in
                        switch workoutResult {
                        case .success(let workoutPlanString):
                            print(workoutPlanString)
                            
                            // Convert workoutPlanString to a 2D array
                            if let formattedWorkout = parseMatrix(from: workoutPlanString) {
                                // Check if the array has dimensions 5 x 7
                                print(formattedWorkout)
                                if formattedWorkout.count ==  7 && formattedWorkout.allSatisfy({ $0.count >= 5}) {
                                    print("Corrected")
                                    saveWorkoutToUserDefaults(workout: formattedWorkout, key: "savedWorkoutPlan")
                                    completion(.success(workoutPlanString))
                                    return
                                } else {
                                    // Retry if the workout array dimensions are incorrect
                                    analyzeAndGenerateWorkout(image: image, retryCount: retryCount + 1, completion: completion)
                                    return
                                }
                                
                            } else {
                                print("Failed to parse the workout plan.")
                                completion(.failure(.lightingIssue)) // Adjust error type as necessary
                                return
                            }
                            
                        case .failure:
                            // Retry if generating the workout plan fails
                            analyzeAndGenerateWorkout(image: image, retryCount: retryCount + 1, completion: completion)
                            return
                        }
                    }
                } else {
                    // Retry if content is invalid
                    analyzeAndGenerateWorkout(image: image, retryCount: retryCount + 1, completion: completion)
                    return
                }
                
            case .failure:
                // Retry if analyzing the image fails
                analyzeAndGenerateWorkout(image: image, retryCount: retryCount + 1, completion: completion)
                return
            }
        }
    }
    
    // Start the process
    analyzeAndGenerateWorkout(image: image, completion: completion)
}




extension Notification.Name {
    static let analysisComplete = Notification.Name("analysisComplete")
}






struct AnalysisPage: View {
    @State var selectedImage: UIImage
    @State private var content: String = ""
    @State private var showAlert = false
    @State private var alertMessage = ""
    @State private var navigateToTabBar = false
    @State private var navigateToPayment = false
    @State private var isLoading = false
    @State private var workoutPlan: String = ""
    @State private var resetUploadPicture: Bool = false
    @State private var currentCaptionIndex = 0
    @State private var rotationAngle: Double = 0
    @State private var selectedTab = 1 // Track the selected tab
    
    @EnvironmentObject var globalContent: GlobalContent

    private let captions = [
        "Analyzing image...",
        "Looking for levels of fat...",
        "Analyzing body type...",
        "Determining level of aesthetic...",
        "Developing customized gym plan..."
    ]
    
    var body: some View {
        VStack {
            if isLoading {
                ZStack {
                    // Background color for loading spinner
                    Color.white
                        .edgesIgnoringSafeArea(.all)

                    VStack {
                        customProgressView()
                            .frame(width: 100, height: 100)

                        Text(captions[currentCaptionIndex])
                            .font(.system(size: 24, weight: .bold))
                            .foregroundColor(.black)
                            .padding()
                            .multilineTextAlignment(.center)
                    }
                    .onAppear {
                        // Start cycling through captions
                        rotateSpinner()
                    }
                }
            } else {
                Image(uiImage: selectedImage)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 200)
                    .padding()
            }

            // Navigation links
            NavigationLink(destination: TabBarView(selectedTab: $selectedTab).navigationBarHidden(true), isActive: $navigateToTabBar) {
                EmptyView()
            }

            NavigationLink(destination: PaymentView(globalImage: selectedImage).navigationBarHidden(true), isActive: $navigateToPayment) {
                EmptyView()
            }
        }
        .navigationTitle("Analysis Page")
        .navigationBarBackButtonHidden(true)  // Hide the back button
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            isLoading = true
            processImageAndText(image: selectedImage, globalContent: globalContent) { result in
                isLoading = false
                switch result {
                case .success(let analysisResult):
                    // After processing image, check subscription status
                    Task {
                        do {
                            let result = try await Superwall.shared.getPresentationResult(forEvent: "discount_trigger")
                            print("Superwall result: \(result)")
                            switch result {
                            case .userIsSubscribed:
                                // User is subscribed, navigate to TabBarView
                                DispatchQueue.main.async {
                                    self.navigateToTabBar = true
                                }
                            case .paywall:
                                // User is not subscribed, navigate to PaymentView
                                DispatchQueue.main.async {
                                    self.navigateToPayment = true
                                }
                            case .holdout:
                                // Handle holdout group, navigate to TabBarView or another view
                                DispatchQueue.main.async {
                                    self.navigateToTabBar = true
                                }
                            case .eventNotFound, .noRuleMatch, .paywallNotAvailable:
                                // Handle other cases, navigate to PaymentView
                                DispatchQueue.main.async {
                                    self.navigateToPayment = true
                                }
                            }
                        } catch {
                            print("Error checking subscription: \(error)")
                            // In case of error, navigate to PaymentView
                            DispatchQueue.main.async {
                                self.navigateToPayment = true
                            }
                        }
                    }
                case .failure(let error):
                    DispatchQueue.main.async {
                        self.alertMessage = "Error analyzing image: \(error)"
                        self.showAlert = true
                    }
                }
            }
        }
        .alert(isPresented: $showAlert) {
            Alert(title: Text("Result"), message: Text(alertMessage), dismissButton: .default(Text("OK")))
        }
    }
    
    private func customProgressView() -> some View {
        ZStack {
            // Background circle
            Circle()
                .stroke(Color.gray.opacity(0.2), lineWidth: 8)
                .frame(width: 100, height: 100)

            // Foreground circle (spinning)
            Circle()
                .trim(from: 0, to: 0.7)
                .stroke(style: StrokeStyle(lineWidth: 8, lineCap: .round))
                .foregroundColor(.black)
                .rotationEffect(.degrees(rotationAngle)) // Apply rotation effect
                .animation(.linear(duration: 1).repeatForever(autoreverses: false), value: rotationAngle) // Continuous rotation
        }
    }
    
    private func rotateSpinner() {
        withAnimation(Animation.linear(duration: 2).repeatForever(autoreverses: false)) {
            rotationAngle = 360
        }
        // Rotate captions
        Timer.scheduledTimer(withTimeInterval: 3, repeats: true) { _ in
            withAnimation {
                currentCaptionIndex = (currentCaptionIndex + 1) % captions.count
            }
        }
    }
}



func encodeImage(image: UIImage, targetSize: CGSize = CGSize(width: 256, height: 256), compressionQuality: CGFloat = 0.3) -> String? {
    guard let imageData = image.jpegData(compressionQuality: compressionQuality) else { return nil }
    return imageData.base64EncodedString(options: .lineLength76Characters)
}


func analyzeImage(image: UIImage, completion: @escaping (Result<String, AnalyzeImageError>) -> Void) {
    print("Analyzing started...")
    guard let base64Image = encodeImage(image: image, compressionQuality: 0.3) else {
        completion(.failure(.encodingError))
        print("Failed to encode image")
        return
    }

    let url = URL(string: "https://api.openai.com/v1/chat/completions")!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.setValue("Bearer sk-proj-WQuq6mEpqoy9EehPkvaxT3BlbkFJY331XxpmExbUaqLSAsTD", forHTTPHeaderField: "Authorization")
    
    let promptMessages = [
        [
            "role": "user",
            "content": [
                "This is an AI-image generated image physique and lets pretend you are a fitness model. Provide a assessment from 0-100 of the fitness of each of the following body parts in the physique: Chest, Abdominal, Shoulders, Arm Definition, Vascularity/Veins, Leanness, Potential. Potential should always be higher than the rest of the ratings and its predicting what the person's maximum genetic potential is. Pretend you're a fitness coach but don't be too critical; Make it so people can get over 90 and not too many people get below 30. Grade from an aesthetics scale and make sure to give impressive physiques like Arnold Shwarsnger score 96 and above. Put the assesment numbers in a Python list format separated by commas in the same line with the respective assesments in order separated by commas. don't add a new line after the comma and do not include any description. Do not include the body part name or anything else but the list. Example Output: [#, #, #, #, #, #, #] ",
                ["image": base64Image, "resize": 768]
            ]
        ]
    ]
    
    let payload: [String: Any] = [
        "model": "gpt-4o-mini",
        "messages": promptMessages,
        "max_tokens": 300
    ]

    do {
        request.httpBody = try JSONSerialization.data(withJSONObject: payload, options: [])
    } catch {
        completion(.failure(.jsonParsingError(error)))
        return
    }

    let task = URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            print("Request error: \(error)")
            completion(.failure(.requestError(error)))
            return
        }

        guard let data = data else {
            print("No data received")
            completion(.failure(.noData))
            return
        }

        do {
            if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                if let error = json["error"] as? [String: Any] {
                    let message = error["message"] as? String ?? "Unknown error"
                    completion(.failure(.jsonParsingError(NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: message]))))
                    return
                }

                if let choices = json["choices"] as? [[String: Any]],
                   let message = choices.first?["message"] as? [String: Any],
                   let content = message["content"] as? String {
                    print(content)
                    completion(.success(content))
                } else {
                    completion(.failure(.jsonParsingError(NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "Invalid JSON structure"]))))
                }
            } else {
                completion(.failure(.jsonParsingError(NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "Invalid JSON format"]))))
            }
        } catch {
            completion(.failure(.jsonParsingError(error)))
        }
    }

    task.resume()
}

func generateWorkoutPlan(basedOn content: String, completion: @escaping (Result<String, AnalyzeImageError>) -> Void) {
    let url = URL(string: "https://api.openai.com/v1/chat/completions")!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.setValue("Bearer sk-proj-WQuq6mEpqoy9EehPkvaxT3BlbkFJY331XxpmExbUaqLSAsTD", forHTTPHeaderField: "Authorization")

    let promptMessageContent = """
        Based on the following strength ratings for Chest, Abdominal, Shoulders, Arm Definition, Vascularity/Veins, and Leanness (in that order): \(content), generate a 7 day workout based on the following exercises exerciseNames = [
        "Incline Dumbbell Press",
        "Flat Bench Press",
        "Dumbbell Flyes",
        "Cable Crossover",
        "Push-ups",
        "Decline Bench Press",
        "Pec Deck Fly",
        "Deadlifts",
        "Pull-ups",
        "Bent Over Rows",
        "T-Bar Rows",
        "Seated Cable Rows",
        "Lat Pulldowns",
        "Single-Arm Dumbbell Rows",
        "Hyperextensions",
        "Shrugs",
        "Overhead Press",
        "Arnold Press",
        "Lateral Raises",
        "Front Raises",
        "Rear Delt Flyes",
        "Face Pulls",
        "Upright Rows",
        "Bicep Curls",
        "Hammer Curls",
        "Preacher Curls",
        "Tricep Dips",
        "Skull Crushers",
        "Overhead Tricep Extensions",
        "Cable Tricep Pushdowns",
        "Squats",
        "Leg Press",
        "Lunges",
        "Deadlifts",
        "Romanian Deadlifts",
        "Leg Extensions",
        "Leg Curls",
        "Calf Raises",
        "Bulgarian Split Squats",
        "Hip Thrusts",
        "Planks",
        "Hanging Leg Raises",
        "Russian Twists",
        "Cable Crunches",
        "Mountain Climbers",
        "Ab Wheel Rollouts",
        "Bicycle Crunches",
        "Toe Touches",
        "Side Planks",
        "Jump Rope",
        "Burpees",
        "Box Jumps",
        "High Knees",
        "Sprints" ]

        
        Output only a 6 x 7 array of the indexes of the exercises from 0 - 50 that you would recommend to the person for each day of the week with the following strength ratings for Chest, Abdominal, Shoulders, Arm Definition, Vascularity/Veins, and Leanness (in that order): \(content). You can use the same exercises more than once but make sure you group each row in terms of day like push, pull, legs. Also order by putting the compound lifts like squat, deadlift, bench press, clean that require most energy in the beginning indices like 0/1. Only output the array with no brackets only commas and new line exactly like this: Ensure there are 5 columns and 7 rows.
        
        #, #, #, #, #, #
        #, #, #, #, #, #
        #, #, #, #, #, #
        #, #, #, #, #, #
        #, #, #, #, #, #
        #, #, #, #, #, #
        #, #, #, #, #, #
        """

    let promptMessage = [
        "role": "user",
        "content": promptMessageContent
    ]

    let payload: [String: Any] = [
        "model": "gpt-4o-mini",
        "messages": [promptMessage],
        "max_tokens": 2000
    ]

    do {
        request.httpBody = try JSONSerialization.data(withJSONObject: payload, options: [])
    } catch {
        completion(.failure(.jsonParsingError(error)))
        return
    }

    let task = URLSession.shared.dataTask(with: request) { data, response, error in
        if let error = error {
            DispatchQueue.main.async {
                completion(.failure(.requestError(error)))
            }
            return
        }

        guard let data = data else {
            DispatchQueue.main.async {
                completion(.failure(.noData))
            }
            return
        }

        do {
            if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
               let choices = json["choices"] as? [[String: Any]],
               let message = choices.first?["message"] as? [String: Any],
               let workoutPlan = message["content"] as? String {
                DispatchQueue.main.async {
                    completion(.success(workoutPlan))
                }
            } else {
                DispatchQueue.main.async {
                    completion(.failure(.jsonParsingError(NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "Invalid JSON structure"]))))
                }
            }
        } catch {
            DispatchQueue.main.async {
                completion(.failure(.jsonParsingError(error)))
            }
        }
    }

    task.resume()
}
