import Foundation

struct WorkoutDay: Identifiable {
    let id = UUID()
    let title: String
    let exercises: [Exercise]
    let explanation: String
}



