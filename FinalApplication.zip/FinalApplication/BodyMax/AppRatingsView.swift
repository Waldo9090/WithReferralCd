import SwiftUI
import StoreKit

struct AppRatingsView: View {
    @State private var isButtonEnabled = false
    @State private var navigateToNextView = false
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack {
            HStack {
                Button(action: {
                    generateHapticFeedback()
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.black)
                }
                Spacer()
            }
            .padding()

            Spacer()
            Text("Rate Our App")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.top, 50)
                .padding(.bottom, 20)

            Text("We hope you are enjoying our app. Please take a moment to rate us!")
                .font(.body)
                .multilineTextAlignment(.center)
                .padding()
            
            Image("5star") // Replace with the name of your image in assets
                .resizable()
                .scaledToFit()
                .frame(width: 200, height: 200)
                .padding()

            Button(action: {
                generateHapticFeedback()
                navigateToNextView = true
            }) {
                Text("Next")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(isButtonEnabled ? Color.black : Color.gray)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            .padding()
            .disabled(!isButtonEnabled) // Disable the button based on `isButtonEnabled`

            Spacer()
        }
        .padding()
        .onAppear {
            // Request review and enable button after 3 seconds
            requestReview()
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                isButtonEnabled = true
            }
        }
        .background(
            NavigationLink(destination: SignInView().navigationBarHidden(true), isActive: $navigateToNextView) {
                EmptyView()
            }
        )
    }

    private func generateHapticFeedback() {
        let impactFeedbackGenerator = UIImpactFeedbackGenerator(style: .medium)
        impactFeedbackGenerator.impactOccurred()
    }

    private func requestReview() {
        if #available(iOS 14.0, *) {
            SKStoreReviewController.requestReview()
        } else {
            // Optionally, handle earlier iOS versions
            print("Review request not available for this iOS version.")
        }
    }
}

struct AppRatingsView_Previews: PreviewProvider {
    static var previews: some View {
        AppRatingsView()
    }
}

